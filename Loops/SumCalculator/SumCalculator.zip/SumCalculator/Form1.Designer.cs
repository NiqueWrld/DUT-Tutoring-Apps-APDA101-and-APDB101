﻿using System;
using System.Windows.Forms;

namespace SumCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxStart = new System.Windows.Forms.TextBox();
            this.textBoxEnd = new System.Windows.Forms.TextBox();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.labelResult = new System.Windows.Forms.Label();
            this.labelStart = new System.Windows.Forms.Label();
            this.labelEnd = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxStart
            // 
            this.textBoxStart.Font = new System.Drawing.Font("MV Boli", 22.2F);
            this.textBoxStart.Location = new System.Drawing.Point(341, 12);
            this.textBoxStart.Name = "textBoxStart";
            this.textBoxStart.Size = new System.Drawing.Size(447, 67);
            this.textBoxStart.TabIndex = 0;
            // 
            // textBoxEnd
            // 
            this.textBoxEnd.Font = new System.Drawing.Font("MV Boli", 22.2F);
            this.textBoxEnd.Location = new System.Drawing.Point(341, 85);
            this.textBoxEnd.Name = "textBoxEnd";
            this.textBoxEnd.Size = new System.Drawing.Size(447, 67);
            this.textBoxEnd.TabIndex = 1;
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Font = new System.Drawing.Font("MV Boli", 22.2F);
            this.buttonCalculate.Location = new System.Drawing.Point(341, 246);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(208, 66);
            this.buttonCalculate.TabIndex = 2;
            this.buttonCalculate.Text = "Calculate Sum";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.Font = new System.Drawing.Font("MV Boli", 22.2F);
            this.labelResult.Location = new System.Drawing.Point(12, 349);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(149, 50);
            this.labelResult.TabIndex = 3;
            this.labelResult.Text = "Result:";
            // 
            // labelStart
            // 
            this.labelStart.AutoSize = true;
            this.labelStart.Font = new System.Drawing.Font("MV Boli", 22.2F);
            this.labelStart.Location = new System.Drawing.Point(12, 15);
            this.labelStart.Name = "labelStart";
            this.labelStart.Size = new System.Drawing.Size(291, 50);
            this.labelStart.TabIndex = 4;
            this.labelStart.Text = "Start Number:";
            // 
            // labelEnd
            // 
            this.labelEnd.AutoSize = true;
            this.labelEnd.Font = new System.Drawing.Font("MV Boli", 22.2F);
            this.labelEnd.Location = new System.Drawing.Point(12, 88);
            this.labelEnd.Name = "labelEnd";
            this.labelEnd.Size = new System.Drawing.Size(259, 50);
            this.labelEnd.TabIndex = 5;
            this.labelEnd.Text = "End Number:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelEnd);
            this.Controls.Add(this.labelStart);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.textBoxEnd);
            this.Controls.Add(this.textBoxStart);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxStart;
        private System.Windows.Forms.TextBox textBoxEnd;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Label labelStart;
        private System.Windows.Forms.Label labelEnd;
    }
}

