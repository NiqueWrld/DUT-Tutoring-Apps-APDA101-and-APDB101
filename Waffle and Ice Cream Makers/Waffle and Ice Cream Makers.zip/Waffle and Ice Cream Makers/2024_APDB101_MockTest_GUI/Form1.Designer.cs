﻿namespace _2024_APDB101_MockTest_GUI
{
    partial class frmMockTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radCinnamon = new System.Windows.Forms.RadioButton();
            this.radHoney = new System.Windows.Forms.RadioButton();
            this.radPlain = new System.Windows.Forms.RadioButton();
            this.lblCost = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkNuts = new System.Windows.Forms.CheckBox();
            this.chkChocPieces = new System.Windows.Forms.CheckBox();
            this.chkFruits = new System.Windows.Forms.CheckBox();
            this.btnHitMe = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Taste buds feel for:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 279);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Top it up:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 442);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(234, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "It\'s gonna cost you:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.radCinnamon);
            this.groupBox1.Controls.Add(this.radHoney);
            this.groupBox1.Controls.Add(this.radPlain);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(207, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(217, 180);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Waffle Type:";
            // 
            // radCinnamon
            // 
            this.radCinnamon.AutoSize = true;
            this.radCinnamon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.radCinnamon.Location = new System.Drawing.Point(19, 129);
            this.radCinnamon.Name = "radCinnamon";
            this.radCinnamon.Size = new System.Drawing.Size(151, 33);
            this.radCinnamon.TabIndex = 2;
            this.radCinnamon.TabStop = true;
            this.radCinnamon.Text = "Cinnamon";
            this.radCinnamon.UseVisualStyleBackColor = false;
            // 
            // radHoney
            // 
            this.radHoney.AutoSize = true;
            this.radHoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.radHoney.Location = new System.Drawing.Point(19, 86);
            this.radHoney.Name = "radHoney";
            this.radHoney.Size = new System.Drawing.Size(108, 33);
            this.radHoney.TabIndex = 1;
            this.radHoney.TabStop = true;
            this.radHoney.Text = "Honey";
            this.radHoney.UseVisualStyleBackColor = false;
            // 
            // radPlain
            // 
            this.radPlain.AutoSize = true;
            this.radPlain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.radPlain.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radPlain.Location = new System.Drawing.Point(19, 41);
            this.radPlain.Name = "radPlain";
            this.radPlain.Size = new System.Drawing.Size(93, 33);
            this.radPlain.TabIndex = 0;
            this.radPlain.TabStop = true;
            this.radPlain.Text = "Plain";
            this.radPlain.UseVisualStyleBackColor = false;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(242, 442);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(215, 29);
            this.lblCost.TabIndex = 4;
            this.lblCost.Text = "Output goes here";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.chkNuts);
            this.groupBox2.Controls.Add(this.chkChocPieces);
            this.groupBox2.Controls.Add(this.chkFruits);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(207, 212);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(229, 193);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Extra add on\'s:";
            // 
            // chkNuts
            // 
            this.chkNuts.AutoSize = true;
            this.chkNuts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.chkNuts.Location = new System.Drawing.Point(19, 146);
            this.chkNuts.Name = "chkNuts";
            this.chkNuts.Size = new System.Drawing.Size(88, 33);
            this.chkNuts.TabIndex = 2;
            this.chkNuts.Text = "Nuts";
            this.chkNuts.UseVisualStyleBackColor = false;
            // 
            // chkChocPieces
            // 
            this.chkChocPieces.AutoSize = true;
            this.chkChocPieces.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.chkChocPieces.Location = new System.Drawing.Point(19, 96);
            this.chkChocPieces.Name = "chkChocPieces";
            this.chkChocPieces.Size = new System.Drawing.Size(182, 33);
            this.chkChocPieces.TabIndex = 1;
            this.chkChocPieces.Text = "Choc Pieces";
            this.chkChocPieces.UseVisualStyleBackColor = false;
            // 
            // chkFruits
            // 
            this.chkFruits.AutoSize = true;
            this.chkFruits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.chkFruits.Location = new System.Drawing.Point(19, 49);
            this.chkFruits.Name = "chkFruits";
            this.chkFruits.Size = new System.Drawing.Size(101, 33);
            this.chkFruits.TabIndex = 0;
            this.chkFruits.Text = "Fruits";
            this.chkFruits.UseVisualStyleBackColor = false;
            // 
            // btnHitMe
            // 
            this.btnHitMe.BackColor = System.Drawing.Color.White;
            this.btnHitMe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHitMe.Location = new System.Drawing.Point(88, 491);
            this.btnHitMe.Name = "btnHitMe";
            this.btnHitMe.Size = new System.Drawing.Size(212, 52);
            this.btnHitMe.TabIndex = 5;
            this.btnHitMe.Text = "Hit me!";
            this.btnHitMe.UseVisualStyleBackColor = false;
            this.btnHitMe.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmMockTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(557, 556);
            this.Controls.Add(this.btnHitMe);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmMockTest";
            this.Text = "Waffle and Ice Cream Makers";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radCinnamon;
        private System.Windows.Forms.RadioButton radHoney;
        private System.Windows.Forms.RadioButton radPlain;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkNuts;
        private System.Windows.Forms.CheckBox chkChocPieces;
        private System.Windows.Forms.CheckBox chkFruits;
        private System.Windows.Forms.Button btnHitMe;
    }
}

