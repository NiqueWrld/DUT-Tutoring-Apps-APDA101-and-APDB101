﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2024_APDB101_MockTest_GUI
{
    public partial class frmMockTest : Form
    {
        public frmMockTest()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double totalPrice = 0;

            if (radPlain.Checked)
            {
                totalPrice += 12;
            }
            else if (radHoney.Checked)
            {
                totalPrice += 20;
            }
            else if (radCinnamon.Checked)
            {
                totalPrice += 17;
            }

            if (chkFruits.Checked)
            {
                totalPrice += 10;
            }

            if (chkChocPieces.Checked)
            {
                totalPrice += 15;
            }

            if (chkNuts.Checked)
            {
                totalPrice += 12;
            }

            lblCost.Text = totalPrice.ToString("C");

        }
    }
}
